﻿Imports MySql.Data.MySqlClient

Module ModuleMatakuliah
    Public myCommand As New MySqlCommand
    Public myAdapter As New MySqlDataAdapter
    Public myData As New DataTable
    Public DR As MySqlDataReader
    Public SQL As String
    Public conn As New MySqlConnection

    Public matakuliah_baru As Boolean
    Public oMatakuliah As New Matakuliah

    Public Sub DBConnect()
        conn.ConnectionString = "server=localhost;" &
        "user id=root;" &
        "password=;" &
        "database=db1akademik"
        Try
            conn.Open()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            If (conn.State = ConnectionState.Open) Then
            Else
                MessageBox.Show("Sorry not connected.")
            End If
        End Try
    End Sub

    Public Sub DBDisconnect()

        If (conn.State = ConnectionState.Open) Then
            conn.Close()
            conn.Dispose()
        End If
    End Sub

End Module