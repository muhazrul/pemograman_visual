﻿Namespace Microsoft
    Friend Class Json
    End Class
End Namespace
