﻿Namespace Microsoft
    Class Json
    End Class
End Namespace
