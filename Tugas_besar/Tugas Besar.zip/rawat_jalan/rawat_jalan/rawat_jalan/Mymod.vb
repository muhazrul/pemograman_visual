﻿Module MyMod
    Public api_folder As String = "rawat_jalan"
    Public dokter_api As String = "http://f0833862.xsph.ru/" & api_folder & "/dokter_api.php"
    Public dokter_baru As Boolean
    Public pasien_api As String = "http://f0833862.xsph.ru/" & api_folder & "/pasien_api.php"
    Public pasien_baru As Boolean
End Module
