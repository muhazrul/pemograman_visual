﻿Namespace Newtonsoft
    Friend Class Json
    End Class
End Namespace
