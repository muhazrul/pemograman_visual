﻿Public Class Dokter
    Public Property nip As String
    Public Property nama As String
    Public Property jk As String
    Public Property spesialis As String
End Class