﻿Module MyMod
    Public api_folder As String = "appakademik"
    Public mahasiswa_api As String = "http://f0833862.xsph.ru/" & api_folder & "/mahasiswa_api.php"
    Public mahasiswa_baru As Boolean
    Public matakuliah_api As String = "http://f0833862.xsph.ru/" & api_folder & "/matakuliah_api.php"
    Public matakuliah_baru As Boolean
    Public dokter_api As String = "http://f0833862.xsph.ru/" & api_folder & "/dokter_api.php"
    Public dokter_baru As Boolean
    Public pasien_api As String = "http://f0833862.xsph.ru/" & api_folder & "/pasien_api.php"
    Public pasien_baru As Boolean
End Module
