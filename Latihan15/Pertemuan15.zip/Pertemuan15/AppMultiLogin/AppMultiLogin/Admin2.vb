﻿Public Class Admin2
    Private Sub Admin2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub
End Class