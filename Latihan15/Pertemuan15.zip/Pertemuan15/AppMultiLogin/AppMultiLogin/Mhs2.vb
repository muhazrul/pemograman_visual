﻿Public Class Mhs2
    Private Sub Mhs2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub
End Class