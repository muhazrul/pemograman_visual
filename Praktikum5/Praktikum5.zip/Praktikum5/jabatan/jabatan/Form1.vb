﻿Public Class Form1
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Select Case txtKodeJabatan.Text
            Case "SERMA" : txtKeterangan.Text = "Sersan Mayor"

            Case "SERKA" : txtKeterangan.Text = "Sersan Kepala "

            Case "SERTU" : txtKeterangan.Text = "Sersan Satu"

            Case Else : txtKeterangan.Text = "Sersan Dua"
        End Select
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
